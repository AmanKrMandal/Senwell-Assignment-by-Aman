const mongoose = require('mongoose');

const employeeSchema = new mongoose.Schema({
  employee_id: String,
  first_name: String,
  last_name: String,
  department: String,
  Address: String,
  hire_date: String,
  dob: String,
  joiningDate: String,
  salary: Number,
});

module.exports = mongoose.model('Employee', employeeSchema);
