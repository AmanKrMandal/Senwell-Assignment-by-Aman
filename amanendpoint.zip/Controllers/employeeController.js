const Employee = require("../Models/Employee");

// Create a new employee
exports.createEmployee = async (req, res) => {
  try {
    const employee = new Employee(req.body);
    await employee.save();
    res.status(201).json({ data: employee, status: true });
  } catch (error) {
    res.status(500).json({ error: error.message, status: false });
  }
};

// Get all an employee
exports.getAllEmployee = async (req, res) => {
  try {
    const employee = await Employee.find();
    res.status(201).json({ data: employee, status: true });
  } catch (error) {
    res.status(500).json({ error: error.message, status: false });
  }
};

// Delete an employee by ID
exports.deleteEmployee = async (req, res) => {
  try {
    const { id } = req.params;
    await Employee.findByIdAndRemove(id);
    res.status(204).json({ data: null, status: true });
  } catch (error) {
    res.status(500).json({ error: error.message, status: false });
  }
};

// Update an employee by ID
exports.updateEmployee = async (req, res) => {
  try {
    const { id } = req.params;
    await Employee.findByIdAndUpdate(id, req.body, {
      new: true,
    });
    res.status(201).json({ data: null, status: true });
  } catch (error) {
    res.status(500).json({ error: error.message, status: false });
  }
};

// Search for an employee by employee_id
exports.searchEmployee = async (req, res) => {
  try {
    const { employee_id } = req.params;
    const employee = await Employee.findOne({ employee_id });
    if (!employee) {
      return res
        .status(404)
        .json({ data: null, status: true, message: "Employee not found" });
    }
    res.status(404).json({ data: employee, status: true });
  } catch (error) {
    res.status(500).json({ error: error.message, status: false });
  }
};

// Filter employees by department
exports.filterByDepartment = async (req, res) => {
  try {
    const { department } = req.params;
    const employees = await Employee.find({ department });
    res.json(employees);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Sort employees by salary (ascending order)
exports.sortBySalary = async (req, res) => {
  try {
    const employees = await Employee.find().sort({ salary: 1 });
    res.json(employees);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
