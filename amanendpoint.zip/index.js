const express = require("express");
const mongoose = require("mongoose");
const employeeRoutes = require("./Routes/employeeRoutes");

const app = express();
const PORT = process.env.PORT || 3000;

// Connect to MongoDB
mongoose
  .connect("mongodb://localhost/amanendpoint", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then((res) => console.log("mongodb connected"))
  .catch((err) => console.log("Error", err.message));

// App level Middleware
app.use(express.json());

// Routes
app.use("/employees", employeeRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
