const express = require("express");
const router = express.Router();
const employeeController = require('../Controllers/employeeController');

// Create a new employee
router.post("/", employeeController.createEmployee);

// Get All an employee
router.get("/", employeeController.getAllEmployee);

// Delete an employee by ID
router.delete("/:id", employeeController.deleteEmployee);

// Update an employee by ID
router.put("/:id", employeeController.updateEmployee);

// Search for an employee by employee_id
router.get('/search/:employee_id', employeeController.searchEmployee);

// Filter employees by department
router.get('/filter/department/:department', employeeController.filterByDepartment);

// Sort employees by salary
router.get('/sort/salary', employeeController.sortBySalary);

module.exports = router;
